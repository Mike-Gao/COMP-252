%
%   COMP 423  Assignment 3  (some Matlab to get you started)
%

%   Read in an image
%   

I =  double(imread('rockface.jpg'));
sizeI = size(I);
heightI = sizeI(1);
widthI = sizeI(2);

figure
image(I/255);

for j = 1:3
  figure
  hist(double(reshape(squeeze(I(:,:,j)),heightI*widthI, 1)),256);
   if (j==1)
      title(['histogram of I_R']);

%  print -deps hist_I_R.eps  

   else if (j==2)
       title(['histogram of I_B']);
       else
	 title(['histogram of I_G']);
       end
   end



end

%  
%   DO ASSIGNMENT HERE....
%



%  Convert from double back to unsigned 8 bit  in order to write
%  out the quantized image.

imwrite(uint8(I),'rockface-quantized','JPEG');


