from PIL import Image
import os
im = Image.open('Mikeintree.jpg');
pixels = im.load()

def quantize(v): return round(v/100.0)*100.0

#pixel 0,0
print pixels[0,0]
#red
print pixels[0,0][0]
for i in range(im.size[0]):
    for j in range(im.size[1]):
        pixels[i,j] =  tuple(map(quantize,pixels[i,j]))

print pixels[0,0]
#im.putdata(pixels)               
im.save('mikequantized.jpg')
