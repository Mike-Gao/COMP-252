#include <stdio.h>
#include <stdlib.h>

/* NOTE: this is just a starting point to help start you off. You can rewrite
 * this entirely, if you wish. */
int main()
{
    int i;

    /* set the random seed */
    srand48(time(NULL)*getpid());

    /*initialize random float between 0 and 1 */
    float f = drand48();
    printf("Random Float: %f\n", f);

    /*Note this will give a compiler warning, since it assumes we *don't* mean
      to do this. However, we do! c is a pointer to the address of f. Since the
      type of *c is an int, this is going to give us the IEEE representation. */
    int *c = &f;

    /* print the bitstring */
    printf("The cooresponding bitstring: ");
    for (i = 31; i >= 0; i--) {

        /*we leftshift the int c by i, and then AND it with 0000...0001 to get
          the final bit */
        printf("%d", *c>>i & 1);
    }
    printf("\n");

    return 0;

}
